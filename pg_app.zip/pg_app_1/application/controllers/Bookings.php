<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bookings extends CI_Controller {

    //
    public function __construct()
    {
        //
        parent::__construct();

        $this->load->model('pgs_model');
        $this->load->model('bookings_model');
        $this->load->model('pg_rating_model');

        if(!$this->ion_auth->logged_in())
        {
            redirect('/', 'refresh');
        }
    }

    //
    public function index()
    {
        if(!$this->ion_auth->in_group(2))
        {
            redirect('/', 'refresh');
        }
        
        $header['title'] = 'My Pg Booking\'s'; 

        $uid = $this->ion_auth->user()->row()->id;

        $data['bookings'] = $this->bookings_model->myPgBookings($uid);

        $this->load->view('layouts/header', $header);
        $this->load->view('bookings/mypg', $data);
        $this->load->view('layouts/footer');
    }

    //
    public function all()
    {
        if(!$this->ion_auth->in_group(1))
        {
            redirect('/', 'refresh');
        }

        $header['title'] = 'All Booking\'s'; 

        $data['bookings'] = $this->bookings_model->all();

        $this->load->view('layouts/header', $header);
        $this->load->view('bookings/all', $data);
        $this->load->view('layouts/footer');
    }

    //
    public function my()
    {
        if(!$this->ion_auth->in_group(3))
        {
            redirect('/', 'refresh');
        }

        $header['title'] = 'My Booking\'s'; 

        $uid = $this->ion_auth->user()->row()->id;

        $data['bookings'] = $this->bookings_model->myBookings($uid);

        $this->load->view('layouts/header', $header);
        $this->load->view('bookings/my', $data);
        $this->load->view('layouts/footer');
    }

    //
    public function rate()
    {
        $rating = $_POST['rating'];

        $user_id = $this->ion_auth->get_user_id();

        $pg_id = $_POST['pgid'];

        $this->pg_rating_model->rate($rating, $user_id, $pg_id);

        return redirect('/bookings/my');
    }

    //
    public function newbooking($id)
    {
        $uid = $this->ion_auth->user()->row()->id;

        $pg_id = $id;

        $this->bookings_model->newbooking($pg_id, $uid);

        return redirect('bookings/my');
    }

}