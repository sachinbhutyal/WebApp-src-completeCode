<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Search extends CI_Controller {

    //
    public function __construct()
    {
        parent::__construct();

        $this->load->model('pgs_model');
    }

    //
    public function index()
    {
        $search = $_GET['s'];

        $data['search'] = $this->pgs_model->search($search);

        $data['title'] = "Search";
        $this->load->view('layouts/header-d', $data);
        $this->load->view('search/index', $data);
        $this->load->view('layouts/footer-d', $data);
    }

}