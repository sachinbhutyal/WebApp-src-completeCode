<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allpgs extends CI_Controller {

    //
    public function __construct()
    {
        //
        parent::__construct();

        $this->load->model('pgs_model');

        if(!$this->ion_auth->in_group(1))
        {
            redirect('/', 'refresh');
        }

        if(!$this->ion_auth->logged_in())
        {
            redirect('/', 'refresh');
        }
    }

    //
    public function index()
    {
        $header['title'] = 'All PG\'s'; 

        $data['pgs'] = $this->pgs_model->all();

        $this->load->view('layouts/header', $header);
        $this->load->view('pgs/all', $data);
        $this->load->view('layouts/footer');
    }

}