<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pgpictures extends CI_Controller {

    //
    public function __construct()
    {
        parent::__construct();
        //

        $this->load->model('pgs_model');
    }

    //
    public function index()
    {
        //
        $header['title'] = 'PG Pictures';

        $uid = $this->ion_auth->user()->row()->id;

        $pg_id = $this->pgs_model->withUserId($uid)->id;

        $data['pictures'] = $this->pgs_model->all_images($pg_id);

        $this->load->view('layouts/header', $header);
        $this->load->view('profile/pictures', $data);
        $this->load->view('layouts/footer');
    }

    //
    public function create()
    {
        //
        $header['title'] = 'Add PG Pictures';
        
        $this->load->view('layouts/header', $header);
        $this->load->view('profile/picture_create');
        $this->load->view('layouts/footer');
    }

    //
    public function createnew()
    {
        $config['upload_path']          = './uploads/pgpictures/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['encrypt_name']         = TRUE;
        $config['max_size']             = 0;
        $config['max_width']            = 0;
        $config['max_height']           = 0;

        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('picture'))
        {
            //var_dump($this->upload->display_errors());
            return redirect('pgpictures/create');
        }
        else
        {
            $uid = $this->ion_auth->user()->row()->id;
            $pg_id = $this->pgs_model->withUserId($uid)->id;

            $file_name = $this->upload->data('file_name');
            $url = base_url("uploads/pgpictures/$file_name");

            $this->pgs_model->add_image($pg_id, $url);

            return redirect('pgpictures');
        }
    }

    //
    public function delete($id)
    {
        $this->pgs_model->delete_image($id);

        return redirect('pgpictures');
    }

}