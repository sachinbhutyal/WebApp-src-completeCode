<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pgprofile extends CI_Controller {

    //
    public function __construct()
    {
        //
        parent::__construct();

        $this->load->model('pgs_model');
        $this->load->model('pg_rating_model');
    }

    //
    public function index()
    {
        if(!$this->ion_auth->in_group(2))
        {
            redirect('/', 'refresh');
        }
        
        if(!$this->ion_auth->logged_in())
        {
            redirect('/', 'refresh');
        }
        
        $this->form_validation->set_rules('name', 'PG', 'required');
        $this->form_validation->set_rules('address', 'PG', 'required');
        $this->form_validation->set_rules('price', 'PG', 'required');
        $this->form_validation->set_rules('map-url', 'PG', 'required');
        $this->form_validation->set_rules('available-rooms', 'PG', 'required');
        $this->form_validation->set_rules('total-rooms', 'PG', 'required');

		if ($this->form_validation->run() == true) {

            $name = $_POST['name'];
            $address = $_POST['address'];
            $price = $_POST['price'];
            $map_url = $_POST['map-url'];
            $available_rooms = $_POST['available-rooms'];
            $total_rooms = $_POST['total-rooms'];
            $description = $_POST['description'];
            $features = $_POST['features'];

            $this->pgs_model->update($name, $address, $price, $map_url, $available_rooms, $total_rooms, $description, $features);

            redirect('pgprofile', 'refresh');
        }

        else {

            $uid = $this->ion_auth->user()->row()->id;
        
            $data['pg'] = $this->pgs_model->withUserId($uid);

            $header['title'] = 'PG Profile';

            $this->load->view('layouts/header', $header);
            $this->load->view('profile/edit', $data);
            $this->load->view('layouts/footer');

        }
    }

    //
    public function show($id)
    {

        $rating = (float)$this->pg_rating_model->get_rating($id);
       
        $data['rating'] = round($rating, 3);

        if($data['rating'] == (float)0)
        {
            $data['rating'] = 'NOT RATED';
        }

        $data['pg'] = $this->pgs_model->single($id);

        $data['title'] = 'PG Details';

        $data['images'] = $this->pgs_model->all_images($id);

        $this->load->view('layouts/header-d', $data);
        $this->load->view('profile/single', $data);
        $this->load->view('layouts/footer-d', $data);

    }

}