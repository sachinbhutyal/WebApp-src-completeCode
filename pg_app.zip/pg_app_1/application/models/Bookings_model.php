<?php
defined('BASEPATH') OR exit('No direct access to the script');

class Bookings_model extends CI_Model {

    //
    public function all()
    {
        $this->db->select('*');
        $this->db->from('bookings');
        $this->db->join('pgs', 'pgs.id = bookings.pg_id');
        $this->db->join('users', 'users.id = bookings.booking_user_id');
        $query = $this->db->get();
        
        return $query->result();
    }

    //
    public function myPgBookings($uid)
    {
        $this->db->select('*');
        $this->db->from('bookings');
        $this->db->join('pgs', 'pgs.id = bookings.pg_id');
        $this->db->join('users', 'users.id = bookings.booking_user_id');
        $this->db->where('pgs.owner_user_id', $uid);

        $query = $this->db->get();

        return $query->result();
    }

    //
    public function myBookings($uid)
    {
        $this->db->select('*');
        $this->db->from('bookings');
        $this->db->join('pgs', 'pgs.id = bookings.pg_id');
        $this->db->join('users', 'users.id = pgs.owner_user_id');
        $this->db->where('bookings.booking_user_id', $uid);

        $query = $this->db->get();

        return $query->result();
    }

    //
    public function newbooking($pg_id, $uid)
    {
        $data = array(
            'booking_user_id' => $uid,
            'pg_id' => $pg_id
        );

        $this->db->insert('bookings', $data);
    }

}