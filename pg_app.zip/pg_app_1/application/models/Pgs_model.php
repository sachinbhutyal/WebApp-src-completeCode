<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Pgs_model extends CI_Model {

    //
    public function all()
    {
        $query = $this->db->get('pgs');
        return $query->result();
    }

    //
    public function search($search)
    {
        $array = array(
            'address' => $search
        );
        $this->db->like($array);
        $query = $this->db->get('pgs');

        return $query->result();
    }

    //
    public function create($name, $address, $google_map_url, $total_rooms, $available_rooms, $uid)
    {
        $data = array(
            'owner_user_id' => $uid,
            'name' => $name,
            'address' => $address,
            'google_map_url' => $google_map_url,
            'total_no_of_rooms' => $total_rooms,
            'available_rooms' => $available_rooms 
        );

        $this->db->insert('pgs', $data);
    }

    //
    public function withUserId($uid)
    {
        $this->db->where('owner_user_id', $uid);
        $query = $this->db->get('pgs');

        return $query->row();
    }

    //
    public function single($id)
    {
        $this->db->where('id', $id);
        $query = $this->db->get('pgs');

        return $query->row();
    }

    //
    public function update($name, $address, $price, $map_url, $available_rooms, $total_rooms, $description, $features)
    {
        $data = array(
            'name' => $name,
            'address' => $address,
            'price' => $price,
            'google_map_url' => $map_url,
            'available_rooms' => $available_rooms,
            'total_no_of_rooms' => $total_rooms,
            'description' => $description,
            'features' => $features
        );

        $this->db->update('pgs', $data);
    }

    //
    public function all_images($id)
    {
        $this->db->where('pg_id', $id);
        $query = $this->db->get('pg_pictures');

        return $query->result();
    }

    //
    public function add_image($pg_id, $url)
    {
        $data = array(
            'pg_id' => $pg_id,
            'picture_url' => $url
        );

        $this->db->insert('pg_pictures', $data);
    }

    //
    public function delete_image($id)
    {
        $this->db->where('id', $id);

        $this->db->delete('pg_pictures');
    }

}