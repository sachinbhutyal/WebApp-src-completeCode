<?php
defined('BASEPATH') OR exit('No direct access to the script');

class Pg_rating_model extends CI_Model {

    //
    public function rate($rating, $user_id, $pg_id)
    {
        //
        $data = [
            'rating' => $rating,
            'rating_user_id' => $user_id,
            'rated_pg_id' => $pg_id
        ];

        $this->db->insert('pg_rating', $data);
    }

    //
    public function get_rating($id)
    {
        $this->db->where('rated_pg_id', $id);

        $this->db->select_avg('rating');

        $query = $this->db->get('pg_rating');

        return $query->result()[0]->rating;
        
    }

}