
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
    <div class="px-2 py-3 row mb-0 mt-3">
        <img class="img-fluid mx-auto d-block pb-3 pt-4 width-65-per" src="<?php echo base_url('assets/images/logo/robust-logo-dark-big.png'); ?>" alt="Robust Search">
        <form method="GET" action="<?php echo base_url('search'); ?>">
        <fieldset class="form-group position-relative">
            <input type="text" class="form-control form-control-lg input-lg" id="iconLeft" placeholder="Search PG's..." name="s">
            <div class="form-control-position">
                <i class="icon-ios-search-strong font-medium-4"></i>
            </div>
        </fieldset>
        <div class="row py-2">
            <div class="col-xs-12 text-xs-center">
                <button type="submit" class="btn btn-primary btn-md"><i class="icon-ios-search-strong"></i> Search</button>
                <?php if(!$this->ion_auth->logged_in()): ?>
                <a href="<?php echo base_url('auth/login'); ?>" class="btn btn-primary btn-md">Login</a>
                <?php endif; ?>
                <?php if($this->ion_auth->logged_in()): ?>
                <a href="<?php echo base_url('auth/logout'); ?>" class="btn btn-primary btn-md">Logout</a>
                <?php endif; ?>
                <span class="dropdown">
                    <button id="btnSearchDrop" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" class="btn btn-warning  btn-md dropdown-toggle dropdown-menu-right"><i class="icon-plus"></i> Registration</button>
                    <span aria-labelledby="btnSearchDrop" class="dropdown-menu mt-1 dropdown-menu-right">
                        <a href="<?php echo base_url('auth/register_owner'); ?>" class="dropdown-item"><i class="icon-cube"></i> Paying Guest</a>
                        <a href="<?php echo base_url('auth/register'); ?>" class="dropdown-item"><i class="icon-ios-person"></i> Genral User</a>
                    </span>
                </span>
            </div>
        </div>
        </form>
    </div>
    <div class="row py-1">
    </div>
</div>

        </div>
      </div>
