<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">
<head>
    <title>Robust PG Finder - <?php echo $title; ?></title>
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.css'); ?>">
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/fonts/icomoon.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/fonts/flag-icon-css/css/flag-icon.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/vendors/css/extensions/pace.css'); ?>">
    <!-- END VENDOR CSS-->
    <!-- BEGIN ROBUST CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap-extended.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/app.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/colors.css'); ?>">
    <!-- END ROBUST CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/core/menu/menu-types/vertical-menu.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/core/menu/menu-types/vertical-overlay-menu.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/core/colors/palette-gradient.css'); ?>">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <!-- END Custom CSS-->
  </head>
  <body data-open="click" data-menu="vertical-menu" data-col="1-column" class="vertical-layout vertical-menu 1-column  blank-page blank-page">
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    <div class="app-content content container-fluid">
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><section class="flexbox-container">
    <div class="col-md-4 offset-md-4 col-xs-10 offset-xs-1  box-shadow-2 p-0">
        <div class="card border-grey border-lighten-3 m-0">
            <div class="card-header no-border">
                <div class="card-title text-xs-center">
                    <div class="p-1"><img src="<?php echo base_url('assets/images/logo/robust-logo-dark.png'); ?>" alt="branding logo"></div>
                </div>
                <h6 class="card-subtitle line-on-side text-muted text-xs-center font-small-3 pt-2"><span>Register your PG with Robust PG's</span></h6>
            </div>
            <div class="card-body collapse in">
                <div class="card-block">
                    <form class="form-horizontal form-simple" method="POST" action="<?php echo base_url('auth/register_owner'); ?>" novalidate>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="owner-name" placeholder="Owner Name" required>
                            <div class="form-control-position">
                                <i class="icon-head"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="email" class="form-control form-control-lg input-lg" name="owner-email" placeholder="Owner Email" required>
                            <div class="form-control-position">
                                <i class="icon-at"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="password" class="form-control form-control-lg input-lg" name="password" placeholder="Password" required>
                            <div class="form-control-position">
                                <i class="icon-android-checkbox-outline"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="pg-name" placeholder="PG Name" required>
                            <div class="form-control-position">
                                <i class="icon-clipboard"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="pg-address" placeholder="PG Address" required>
                            <div class="form-control-position">
                                <i class="icon-home"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="map-url" placeholder="Map Url" required>
                            <div class="form-control-position">
                                <i class="icon-map"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="total-rooms" placeholder="Total Rooms" required>
                            <div class="form-control-position">
                                <i class="icon-ios-keypad"></i>
                            </div>
                        </fieldset>
                        <fieldset class="form-group position-relative has-icon-left mb-0">
                            <input type="text" class="form-control form-control-lg input-lg" name="available-rooms" placeholder="Available Rooms" required>
                            <div class="form-control-position">
                                <i class="icon-ios-keypad"></i>
                            </div>
                        </fieldset>
                        <button type="submit" class="btn btn-primary btn-lg btn-block"><i class="icon-unlock2"></i> Register</button>
                    </form>
                </div>
            </div>
            <div class="card-footer">
                <div class="">
                    <p class="float-sm-right text-xs-center m-0">Existing User? <a href="<?php echo base_url('auth/login'); ?>" class="card-link">Sign In</a></p>
                </div>
            </div>
        </div>
    </div>
</section>

        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo base_url('assets/js/core/libraries/jquery.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/tether.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/core/libraries/bootstrap.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/perfect-scrollbar.jquery.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/unison.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/blockUI.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/jquery.matchHeight-min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/screenfull.min.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/extensions/pace.min.js'); ?>"" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="<?php echo base_url('assets/js/core/app-menu.js'); ?>"" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/core/app.js'); ?>"" type="text/javascript"></script>
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
  </body>
</html>
