<div class="card">
    <div class="card-header">
        <h4 class="card-title">All Booking's</h4>
    </div>
    <div class="card-body collapse in">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>PG Name</th>
                        <th>Booking User Name</th>
                        <th>Booking User Email</th>
                        <th>Bookings Timestamp</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $counter = 1; ?>
                    <?php foreach($bookings as $booking): ?>
                    <tr>
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $booking->name; ?></td>
                        <td><?php echo $booking->first_name; ?></td>
                        <td><?php echo $booking->email; ?></td>
                        <td><?php echo $booking->timestamp; ?></td>
                        <?php $counter++; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>