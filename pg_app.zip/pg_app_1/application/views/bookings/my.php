<div class="card">
    <div class="card-header">
        <h4 class="card-title">All Booking's</h4>
    </div>
    <div class="card-body collapse in">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>PG Name</th>
                        <th>PG Owner Email</th>
                        <th>Bookings Timestamp</th>
                        <th>Rating</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $counter = 1; ?>
                    <?php foreach($bookings as $booking): ?>
                    <tr>
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $booking->name; ?></td>
                        <td><?php echo $booking->email; ?></td>
                        <td><?php echo $booking->timestamp; ?></td>
                        <td>
                            <form action="<?php echo base_url('/bookings/rate'); ?>" method="post" class="form-inline">
                                <select name="rating" class="form-control">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                    <?php endfor; ?>
                                </select>
                                <input type="hidden" name="pgid" value="<?php echo $booking->pg_id; ?>" />
                                <button class="btn btn-sm btn-success" type="submit">Rate</button>
                            </form>
                        </td>
                        <?php $counter++; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>