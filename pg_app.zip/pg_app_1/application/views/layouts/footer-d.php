</div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->


    <footer class="footer navbar-fixed-bottom footer-dark navbar-border">
      <p class="clearfix text-muted text-sm-center mb-0 px-2">
      <span class="float-md-left d-xs-block d-md-inline-block">Copyright  &copy; 2020 <a href="<?php echo base_url(); ?>" class="text-bold-800 grey darken-2">PG FINDER </a>, All rights reserved. </span>
      <span class="float-md-right d-xs-block d-md-inline-block">
      Hand-crafted & Made with <i class="icon-heart5 pink"></i>
      </span></p>
    </footer>

    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo base_url('assets/js/core/libraries/jquery.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/tether.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/core/libraries/bootstrap.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/perfect-scrollbar.jquery.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/unison.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/blockUI.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/jquery.matchHeight-min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/ui/screenfull.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/vendors/js/extensions/pace.min.js'); ?>" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="<?php echo base_url('assets/vendors/js/charts/chart.min.js'); ?>" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN ROBUST JS-->
    <script src="<?php echo base_url('assets/js/core/app-menu.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/core/app.js'); ?>" type="text/javascript"></script>
    <!-- END ROBUST JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="<?php echo base_url('assets/js/scripts/pages/dashboard-lite.js'); ?>" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>