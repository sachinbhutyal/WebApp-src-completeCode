<div class="card">
    <div class="card-header">
        <h4 class="card-title">
            Add PG Pictures
        </h4>
    </div>
    <div class="card-body collapse in p-2">
        <form class="form" method="POST" action="<?php echo base_url('pgpictures/createnew'); ?>" enctype="multipart/form-data">
            <div class="form-body">

                <div class="form-group">
                    <label for="1">Picture</label>
                    <input type="file" id="1" class="form-control" name="picture">
                </div>

            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <i class="icon-check2"></i> Create
                </button>
            </div>
        </form>
    </div>
</div>