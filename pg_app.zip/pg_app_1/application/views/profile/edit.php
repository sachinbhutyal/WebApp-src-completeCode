<div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit PG</h4>
    </div>
    <div class="card-body collapse in p-2">
                        <form class="form" method="POST" action="<?php echo base_url('pgprofile'); ?>">
							<div class="form-body">

								<div class="form-group">
									<label for="1">Name</label>
									<input type="text" id="1" class="form-control" value="<?php echo $pg->name; ?>" placeholder="PG Name" name="name">
								</div>

								<div class="form-group">
									<label for="2">Address</label>
									<input type="text" id="2" class="form-control" value="<?php echo $pg->address; ?>" placeholder="Adderss" name="address">
								</div>

								<div class="form-group">
									<label for="7">Price</label>
									<input type="text" id="7" class="form-control" value="<?php echo $pg->price; ?>" placeholder="Price" name="price">
								</div>

                                <div class="form-group">
									<label for="3">Google Map URL</label>
									<input type="text" id="3" class="form-control" value="<?php echo $pg->google_map_url; ?>" placeholder="Map Url" name="map-url">
								</div>

								<div class="form-group">
									<label for="4">Available Room</label>
									<input type="text" id="4" class="form-control" value="<?php echo $pg->available_rooms; ?>" placeholder="Available Rooms" name="available-rooms">
								</div>

                                <div class="form-group">
									<label for="5">Total Rooms</label>
									<input type="text" id="5" class="form-control" value="<?php echo $pg->total_no_of_rooms; ?>" placeholder="Total Rooms" name="total-rooms">
								</div>

								<div class="form-group">
									<label for="6">Description</label>
									<textarea id="6" rows="5" class="form-control" name="description" placeholder="Description"><?php echo $pg->description; ?></textarea>
								</div>

                                <div class="form-group">
									<label for="7">Features</label>
									<textarea id="7" rows="5" class="form-control" name="features" placeholder="Features"><?php echo $pg->description; ?></textarea>
								</div>

							</div>

							<div class="form-actions">
								<button type="reset" class="btn btn-warning mr-1">
									<i class="icon-cross2"></i> Cancel
								</button>
								<button type="submit" class="btn btn-primary">
									<i class="icon-check2"></i> Save
								</button>
							</div>
						</form>
    </div>
</div>