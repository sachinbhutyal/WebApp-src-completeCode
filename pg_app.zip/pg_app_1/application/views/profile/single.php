      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
        <section class="m-4">
<div class="container">
  <div class="row">
  <div class="card">
    <div class="card-header">
        <h4 class="card-title">PG &nbsp; &nbsp;
        <?php if($this->ion_auth->in_group(3)): ?>
        <a href="<?php echo base_url("bookings/newbooking/$pg->id"); ?>" class="btn btn-sm btn-primary">Book</a>
        <?php endif; ?>
        </h4>
    </div>
    <div class="card-body collapse in p-2">
        <div class="form-body">

            <div class="form-group">
                <label for="1"><b>Name: </b><?php echo $pg->name; ?></label>
            </div>

            <div class="form-group">
                <label for="2"><b>Address: </b><?php echo $pg->address; ?></label>
            </div>

            <div class="form-group">
                <label for="4"><b>Price: </b><?php echo $pg->price; ?></label>
            </div>

            <div class="form-group">
                <label for="3"><b>Directions: </b><a href="<?php echo $pg->google_map_url; ?>"><button class="btn btn-small btn-primary"> Directions </button></a></label>
            </div>

            <div class="form-group">
                <label for="4"><b>Available Room: </b><?php echo $pg->available_rooms; ?></label>
            </div>

            <div class="form-group">
                <label for="5"><b>Total Rooms: </b><?php echo $pg->total_no_of_rooms; ?></label>
            </div>

            <div class="form-group">
                <label for="5"><b>Rating: </b><?php echo $rating; ?></label>
            </div>

            <div class="form-group">
                <label for="6"><b>Description: </b><?php echo $pg->description; ?></label>
            </div>

            <div class="form-group">
                <label for="7"><b>Features: </b><?php echo $pg->features; ?></label>
            </div>

            <div class="form-group">
                <label for="10"><b>Images: </b></label>
                <table class="table">
                    <?php foreach($images as $image): ?>
                    <tr class="col-lg-6 col-md-6">
                        <td><img src="<?php echo $image->picture_url; ?>" width="100%" /></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>

        </div>
    </div>
</div>
  </div>
</div>
</section>
        </div>
      </div>