<div class="card">
    <div class="card-header">
        <h4 class="card-title">
            PG Pictures &nbsp; &nbsp;<a href="<?php echo base_url('pgpictures/create'); ?>" class="btn btn-sm btn-primary">ADD MORE <i class="icon-android-add"></i></a>
        </h4>
    </div>
    <div class="card-body collapse in">
        <div class="table-responsive">
            <table class="table">
                <tbody>
                    <?php foreach($pictures as $picture): ?>
                    <tr class="col-lg-6 col-md-6">
                        <td>
                            <img src="<?php echo $picture->picture_url; ?>" width="100%" />
                            <br /><a href="<?php echo base_url("pgpictures/delete/$picture->id"); ?>" class="btn btn-danger btn-sm mt-1">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>