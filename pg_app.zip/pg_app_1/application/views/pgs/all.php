<div class="card">
    <div class="card-header">
        <h4 class="card-title">All PG's</h4>
    </div>
    <div class="card-body collapse in">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Total Rooms</th>
                        <th>Available Rooms</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $counter = 1; ?>
                    <?php foreach($pgs as $pg): ?>
                    <tr>
                        <td><?php echo $counter; ?></td>
                        <td><?php echo $pg->name; ?></td>
                        <td><?php echo $pg->address; ?></td>
                        <td><?php echo $pg->total_no_of_rooms; ?></td>
                        <td><?php echo $pg->available_rooms; ?></td>
                        <?php $counter++; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>