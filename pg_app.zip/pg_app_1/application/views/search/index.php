
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3">
        <section class="m-4">
<div class="container">
  <div class="row">
    <?php if(!empty($search)): ?>
    <div class="table-responsive">
      <table class="table">
        <thead class=" text-primary">
          <tr><th>
            #
          </th>
          <th>
            Name
          </th>
          <th>
            Address
          </th>
          <th>
            Price
          </th>
          <th>
            Available Rooms
          </th>
          <th></th>
        </tr></thead>
        <tbody>
        <?php $count = 1; ?>
        <?php foreach($search as $s): ?>
          <tr>
            <td>
              <?php echo $count; ?>
            </td>
            <td>
              <?php echo $s->name; ?>
            </td>
            <td>
              <?php echo $s->address; ?>
            </td>
            <td>
              <?php echo $s->price; ?>
            </td>
            <td>
                <?php echo $s->total_no_of_rooms; ?>
            </td>
            <td>
              <a href='<?php echo base_url("pgprofile/show/$s->id");?>' class="btn btn-primary">Know More</a>
            </td>
          </tr> 
          <?php $count++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
    <?php if(empty($search)): ?>
      <div class="container mt-4">
      <h3>Sorry! No results were found</h3>
      <h6>Please click on the button below to go back to the homepage</h6>
      <a href="<?php echo base_url(); ?>">
        <button class="btn btn-primary">
          Go Back
        </button>
      </a>
      </div>
    <?php endif; ?>
  </div>
</div>
</section>
        </div>
      </div>